package com.cognizant.tests;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.dao.VendorDao;
import com.cognizant.model.Vendor;
import com.cognizant.service.VendorService;

import static org.mockito.Mockito.*;

@SuppressWarnings("deprecation")
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace =Replace.NONE)
@TestMethodOrder(OrderAnnotation.class)
public class VendorServiceTest {
	
	@Mock
	private VendorDao vendorDao;
	@InjectMocks
	private VendorService vendorService;
    
	Vendor vendor=new Vendor(1,"suresh","busayavalasa","male","7095012779","RTC","Hyderabad","AP","5320001",
	  		  "jaga@gmail.com","425","password","what is childhoodname","jagadeesh");
	/*@Test
	@Rollback(true)
	@Order(1)
	public void testCreateVendor() {
		Vendor vendor=vendorDao.save(new Vendor(1,"suresh","busayavalasa","male","7095012779","RTC","Hyderabad","AP","5320001",
	  		  "jaga@gmail.com","425","password","what is childhoodname","jagadeesh"));
		assertEquals("425",vendor.getVendorUserId());
	}
	@Test
	@Rollback(true)
	@Order(2)
	public void testfindByVendorUserId() {
		Vendor vendor1=vendorDao.findByVendorUserId("425");
		assertEquals("suresh",vendor1.getFirstName());
	}
	*/
	
	@Test
	public void testfindByVendorUserId() {
		
		
		   //vendor.setFirstName("jagadeesh");
		when(vendorDao.findByVendorUserId("425")).thenReturn(vendor);
		
		
	               Vendor vendor1= vendorService.findByVendorUserId("425");
	               assertNotNull(vendor1);
	               assertEquals("suresh",vendor1.getFirstName());
	               
	               
	}
	@Test
	public void testFindByUserIdAndPassword() {
		
  	       // when(vendorDao.save(new Vendor())).thenReturn(vendor);
  	     when(vendorDao.findByVendorUserIdAndPassword("425", "password")).thenReturn(vendor);
	        
	             // vendorService.save(vendor);
	             Vendor vendor1= vendorService.findByVendorUserIdAndPassword("425", "password");
	             assertEquals("suresh",vendor1.getFirstName());
	             
	   }
	@Test
	public void testcreateVendor() {
		// when(vendorDao.save(new Vendor())).thenReturn(vendor);
		vendorService.save(vendor);
		
	}
	@Test
	public void testvalidateSecretAns() {
		String userId="425";
		String secretQ="what is childhoodname";
		String secretAns="jagadeesh";
	
		when(vendorDao.findByVendorUserIdAndSecretQAndSecretAns(userId,secretQ,secretAns)).thenReturn(vendor);
					boolean b=vendorService.validateSecretAns(userId,secretQ,secretAns);
					assertTrue(b);
	}
	

}
