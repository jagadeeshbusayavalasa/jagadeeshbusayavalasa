package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ServicePayment;
@Repository
public interface ServicePaymentDao extends JpaRepository<ServicePayment, Integer> {

	@Query(value = "select * from service_payment where status=?1 and customer_id=?2",nativeQuery = true)
	List<ServicePayment> findAllByServiceIdAndCustomerId(String status,int customerId);
	
	@Query(value = "select * from service_payment where status=?1 and vendor_id=?2",nativeQuery = true)
	List<ServicePayment> findAllByServiceIdAndVendorId(String status, int vendorId);
	
	@Query(value = "select * from service_payment where service_payment_id=?1",nativeQuery = true)
	ServicePayment findByServicePaymentId(int servicePaymentId);
	
	
}
