package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ServicePaymentDao;
import com.cognizant.model.ServicePayment;
@Service
public class ServicePaymentService {
	@Autowired
	private ServicePaymentDao servicePaymentDao;

	public List<ServicePayment> findAllByServiceIdAndVendorId(String status, int vendorId) {
		return servicePaymentDao.findAllByServiceIdAndVendorId(status, vendorId);
	}

	public ServicePayment findByServicePaymentId(int servicePaymentId) {
		return servicePaymentDao.findByServicePaymentId(servicePaymentId);
	}

	public void save(ServicePayment servicePayment) {
		servicePaymentDao.save(servicePayment);
		
	}

	public List<ServicePayment> findAllByServiceIdAndCustomerId(String status, int customerId) {
		return servicePaymentDao.findAllByServiceIdAndCustomerId(status, customerId);
	}

}
