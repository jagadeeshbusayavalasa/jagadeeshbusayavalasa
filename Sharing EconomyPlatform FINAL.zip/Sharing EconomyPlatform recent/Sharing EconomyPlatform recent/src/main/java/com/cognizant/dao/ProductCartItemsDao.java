package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ProductCart;
import com.cognizant.model.ProductCartItems;
@Repository
public interface ProductCartItemsDao extends JpaRepository<ProductCartItems, Integer>{

	List<ProductCartItems> findAllByCustomerId(int customerId);

	ProductCartItems findByCartItemIdAndCustomerId(int cartItemId, int customerId);


}
