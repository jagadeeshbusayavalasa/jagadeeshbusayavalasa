package com.cognizant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ProductCart;
@Repository
public interface ProductCartDao extends JpaRepository<ProductCart, Integer> {

}
