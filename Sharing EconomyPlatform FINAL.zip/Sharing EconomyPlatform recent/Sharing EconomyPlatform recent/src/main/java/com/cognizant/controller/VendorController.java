package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ProductService;
import com.cognizant.service.ServiceCategoryService;
import com.cognizant.service.ServicePaymentService;
import com.cognizant.service.ServiceService;
import com.cognizant.service.VendorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.ServiceObject;
import com.cognizant.model.ServiceCategory;
import com.cognizant.model.ServicePayment;
import com.cognizant.model.Vendor;

@Controller
public class VendorController {
	@Autowired
	private VendorService vendorService;
	@Autowired
	private ServiceService serviceService;
	@Autowired
	private ProductService productService;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ServicePaymentService servicePaymentService;
	@Autowired
	private ProductCategoryService productCategoryService;
	@Autowired
	private ServiceCategoryService serviceCategoryService;

	// displays registration form
	@GetMapping("/vendor")
	public String viewVendorRegister(Model model) {
		Vendor vendor = new Vendor();
		model.addAttribute("vendor", vendor);
		return "vendorRegister";
	}

	// validation and registration
	@PostMapping("/vendorRegister")
	public String addVendor(@Valid @ModelAttribute("vendor") Vendor vendor, BindingResult result, ModelMap map) {
		if (result.hasErrors()) {
			return "vendorRegister";
		}

		vendorService.save(vendor);
		return "vendorRegisterSuccess";
	}

	// display login form
	@GetMapping("/vendorLogin")
	public String vendorLogin() {

		return "vendorLogin";
	}

	// login
	@PostMapping("/vendorAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password, HttpSession session, Model model, HttpServletRequest request) {
		Vendor vendor = vendorService.findByVendorUserIdAndPassword(username, password);
		if (!(ObjectUtils.isEmpty(vendor))) {
			session.setAttribute("username", username);
			return "vendorDetails";
		} else {
			System.out.println("false");
			model.addAttribute("msg", "Invalid Login Credentials");
			return "vendorLogin";
		}
	}

	// logout
	@GetMapping("/vendorLogout")
	public String logout(HttpSession session) {
		session.removeAttribute("username");
		return "redirect:/";
	}
	
	
	 @GetMapping("/forgotpassword")
	 public String forgotPassword()
	 {
		 return "vendorForgotPassword";
	 }
	 
	 @PostMapping("/vendorsecretans")
	 public String secretansAuthgentication(@RequestParam("vendorUserId") String vendorUserId,@RequestParam("secretQ") String secretQ,
			 @RequestParam("secretAns") String secretAns,Model model,HttpSession session) 
	 {
		 boolean isValid=vendorService.validateSecretAns(vendorUserId,secretQ,secretAns);
		 if(isValid) {
			
			 session.setAttribute("vendorUserId", vendorUserId);
			 Vendor vendor =vendorService.findByVendorUserId((String)session.getAttribute("vendorUserId"));
			 model.addAttribute("vendorname",vendor.getFirstName());
			 
			 return "vendorPasswordReset";
			 }
		 
		 else {
			 model.addAttribute("msg", "Sorry! Incorrect Answer");
			 return "vendorForgotPassword";
		 }
	 }
	 
	 @PostMapping("/vendorresetpassword")
	 public String resetPassword(@RequestParam("password") String password,HttpSession session) {
		 String vendorUserId=(String)session.getAttribute("vendorUserId");
		 vendorService.resetPassword(vendorUserId,password);
		 return "vendorLogin";
	 }

	
	
	
	@GetMapping("/vendorupdate")
	public String vendorUpdate(ModelMap map,HttpSession session,HttpServletRequest request) {
	   
	  Vendor vendor =vendorService.findByVendorUserId((String)session.getAttribute("username"));
	     map.addAttribute("vendor", vendor);
	     map.addAttribute("vendorname",vendor.getFirstName());
	     request.setAttribute("mode", "MODE_UPDATEPROFILE");
		return "vendorDetails";
	
	}
	@PostMapping("/updateauthentication")

	public  String vendorUpdateAuthenticatio(@ModelAttribute("vendor") Vendor vendor,Model model,HttpSession session,BindingResult result,
			@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,@RequestParam("gender") String gender,
			@RequestParam("city") String city,@RequestParam("state") String state,@RequestParam("zip") String zip,
			@RequestParam("address") String address,@RequestParam("contactNumber") String contactNumber,@RequestParam("email") String email)
		 {
		 
			String currentSession=(String) session.getAttribute("username");
			vendorService.update(currentSession, firstName, lastName, gender, contactNumber, address, city, state, zip, email);
		   		    model.addAttribute("msg", "Updated Successfully");
			 return "vendorDetails";
		
		
	}

	// gets list of product category to display in drop-down from db
	@GetMapping("/productCategories")
	@ResponseBody
	public List<String> getProductCategories(HttpSession session) {
		
		List<String> productCategories = productCategoryService.getProductCategories();
		return productCategories;
	}

	// gets list of service category to display in drop-down from db
	@GetMapping("/serviceCategories")
	@ResponseBody
	public List<String> getServiceCategories(HttpSession session) {
		
		List<String> serviceCategories = serviceCategoryService.getServiceCategories();
		return serviceCategories;
	}

	// display add product category form
	@GetMapping("/viewAddproduct")
	public String showAddProduct(@RequestParam("categoryName") String categoryName, Model model,
			HttpServletRequest request, HttpSession session) {
		ProductCategory productCategory = productCategoryService.findProductCategoryByProductCategoryName(categoryName);
		request.setAttribute("categoryName", categoryName);
		session.setAttribute("productCategory", categoryName);
		request.setAttribute("mode", "MODE_VIEWADDPRODUCT");
		return "vendorDetails";
	}

	// display add service category form
	@GetMapping("/viewAddservice")
	public String showAddService(@RequestParam("categoryName") String categoryName, Model model,
			HttpServletRequest request, HttpSession session) {
		ServiceCategory serviceCategory = serviceCategoryService.findServiceCategoryByServiceCategoryName(categoryName);
		model.addAttribute("category", serviceCategory);
		session.setAttribute("serviceCategory", categoryName);
		request.setAttribute("mode", "MODE_VIEWADDSERVICE");
		return "vendorDetails";
	}

	// adds the product in db
	@RequestMapping("/viewAddproduct/addProduct")
	public String addProduct(@ModelAttribute("product") Product product, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		String categoryName = (String) session.getAttribute("productCategory");
		ProductCategory productCategory= productCategoryService.findByProductCategoryName(categoryName);
		product.setVendor(vendor);
		productCategory.setVendor(vendor);
		product.setProductCategory(productCategory);
		productService.save(product);
		return "vendorDetails";

	}

	// adds service in db
	@RequestMapping("/viewAddservice/addService")
	public String addService(@ModelAttribute("service") ServiceObject service, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		String categoryName = (String) session.getAttribute("serviceCategory");
		ServiceCategory serviceCategory = serviceCategoryService.findByServiceCategoryName(categoryName);
		service.setVendor(vendor);
		service.setServiceCategory(serviceCategory);
		serviceService.save(service);		
		return "vendorDetails";

	}

	// display add product category form
	@GetMapping("/viewAddProductCategory")
	public String viewAddProductCategory(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDPRODUCTCATEGORY");
		return "vendorDetails";

	}

	// display add service category form
	@GetMapping("/viewAddServiceCategory")
	public String viewAddServiceCategory(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDSERVICECATEGORY");
		return "vendorDetails";

	}

	// add product category in db
	@RequestMapping("/addProductCategory")
	public String addProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory, ModelMap map,
			HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		System.out.println(vendorUserId);
		System.out.println(productCategory);
		//productCategoryDao.save(productCategory);		
		productCategoryService.save(productCategory);
		productCategory.setVendor(vendor);
		System.out.println(productCategory);
		productCategoryService.save(productCategory);
		//productCategoryDao.save(productCategory);
		return "vendorDetails";

	}

	// add service category in db
	@RequestMapping("/addServiceCategory")
	public String addServiceCategory(@ModelAttribute("serviceCategory") ServiceCategory serviceCategory, ModelMap map,
			HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		serviceCategory.setVendor(vendor);
		serviceCategoryService.save(serviceCategory);
		return "vendorDetails";

	}

	// display list of product added by vendor
	@GetMapping("/viewProducts")
	public String viewProducts(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		List<Product> products=vendor.getProduct();	
		model.addAttribute("products",products);
		request.setAttribute("mode", "MODE_VIEWPRODUCTS");
		return "vendorDetails";

	}

	// display list of service added by vendor
	@GetMapping("/viewServices")
	public String viewServices(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		List<ServiceObject> services=vendor.getService();
		model.addAttribute("services", services);
		request.setAttribute("mode", "MODE_VIEWSERVICES");
		return "vendorDetails";

	}

	// display list of product category added by vendor
	@GetMapping("/viewProductCategorys")
	public String viewProductCategorys(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		List<ProductCategory> productCategories=vendor.getProductCategory();
		model.addAttribute("productCategories", productCategories);
		request.setAttribute("mode", "MODE_VIEWPRODUCTCATEGORYS");
		return "vendorDetails";

	}

	// display list of service category added by vendor
	@GetMapping("/viewServiceCategorys")
	public String viewServiceCategorys(HttpServletRequest request,HttpSession session,Model model) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		List<ServiceCategory> serviceCategories=vendor.getServiceCategory();
		model.addAttribute("serviceCategories", serviceCategories);
		request.setAttribute("mode", "MODE_VIEWSERVICECATEGORYS");		
		return "vendorDetails";

	}
	
	//display edit product form
	@GetMapping("/viewEditProduct")
	public String viewEditProduct(@RequestParam("productId") int productId,Model model,HttpServletRequest request,HttpSession session) {
		Product product=productService.findByProductId(productId);
		session.setAttribute("productId", productId);
		model.addAttribute("product",product);
		session.setAttribute("productId",productId);
		request.setAttribute("mode", "MODE_VIEWEDITPRODUCT");
		return "vendorDetails";
		
	}
	
	//display edit service form
	@GetMapping("/viewEditService")
	public String viewEditService(@RequestParam("serviceId") int serviceId,Model model,HttpServletRequest request,HttpSession session) {
		ServiceObject service=serviceService.findByServiceId(serviceId);
		session.setAttribute("serviceId", serviceId);
		model.addAttribute("service",service);
		session.setAttribute("serviceId", serviceId);
		request.setAttribute("mode", "MODE_VIEWEDITSERVICE");
		return "vendorDetails";
		
	}
	
	
	@PostMapping("/viewEditProduct/editProduct")
	public String editProduct(@ModelAttribute("product") Product product, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		
		int productId=(int) session.getAttribute("productId");
		Product product2=productService.findByProductId(productId);
		product2.setPrice(product.getPrice());
		product2.setProductName(product.getProductName());
		product2.setStatus(product.getStatus());
		product2.setVendor(vendor);
		productService.save(product2);
		return "redirect:/viewProducts";

	}
	
	//edits the services
	@PostMapping("/viewEditService/editService")
	public String editService(@ModelAttribute("service") ServiceObject service, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int serviceId=(int) session.getAttribute("serviceId");
		ServiceObject service2=serviceService.findByServiceId(serviceId);
		service2.setPrice(service.getPrice());
		service2.setServiceName(service.getServiceName());
		service2.setStatus(service.getStatus());
		service2.setTimeings(service.getTimeings());
		service2.setContactNumber(service.getContactNumber());
		service2.setZip(service.getZip());
		service2.setVendor(vendor);
		serviceService.save(service2);
		
		return "redirect:/viewServices";

	}
		
	//deletes the product
	@GetMapping("/deleteProduct")
	public String deleteProduct(@RequestParam("productId") int productId,HttpSession session) {
		
		Product product=productService.findByProductId(productId);
		
		productService.delete(product);	
		
		return "redirect:/viewProducts";
	}
	
	//deletes the service
	@GetMapping("/deleteService")
	public String deleteService(@RequestParam("serviceId") int serviceId,HttpSession session) {
		
		ServiceObject service=serviceService.findByServiceId(serviceId);
		serviceService.delete(service);
		
		return "redirect:/viewServices";
	}
	
	
	//display edit product form
	@GetMapping("/viewEditProductCategory")
	public String viewEditProductCategory(@RequestParam("productCategoryId") int productCategoryId,HttpSession session,Model model,HttpServletRequest request) {
		ProductCategory productCategory=productCategoryService.findAllByProductCategoryId(productCategoryId);
		model.addAttribute("productCategory",productCategory);
		session.setAttribute("productCategoryId",productCategoryId);
		request.setAttribute("mode", "MODE_VIEWEDITPRODUCTCATEGORY");
		return "vendorDetails";
		
	}
	
	//display edit service form
	@GetMapping("/viewEditServiceCategory")
	public String viewEditServiceCategory(@RequestParam("serviceCategoryId") int serviceCategoryId,HttpSession session,Model model,HttpServletRequest request) {
		ServiceCategory serviceCategory=serviceCategoryService.findByServiceCategoryId(serviceCategoryId);
		model.addAttribute("serviceCategory",serviceCategory);
		session.setAttribute("serviceCategoryId", serviceCategoryId);
		request.setAttribute("mode", "MODE_VIEWEDITSERVICECATEGORY");
		return "vendorDetails";
		
	}
	
		
	//edits the product
	@PostMapping("/viewEditProductCategory/editProductCategory")
	public String editProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory,@RequestParam("productCategoryName") String productCategoryName, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		int productCategoryId =(int) session.getAttribute("productCategoryId");
		request.setAttribute("productCategoryId", productCategoryId);
		productCategory.setProductCategoryId(productCategoryId);
		productCategory.setProductCategoryName(productCategoryName);
		productCategory.setVendor(vendor);
		productCategoryService.save(productCategory);
		
		return "redirect:/viewProductCategorys";

	}
	
	//edits the services
	@PostMapping("/viewEditServiceCategory/editServiceCategory")
	public String editServiceCategory(@ModelAttribute("serviceCategory") ServiceCategory serviceCategory,@RequestParam("serviceCategoryName") String serviceCategoryName, HttpSession session,
			HttpServletRequest request) {
		String vendorUserId = (String) session.getAttribute("username");
		System.out.println(vendorUserId);
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		int serviceCategoryId =(int) session.getAttribute("serviceCategoryId");
		
		request.setAttribute("serviceCategoryId", serviceCategoryId);
		
		serviceCategory.setServiceCategoryId(serviceCategoryId);
		serviceCategory.setServiceCategoryName(serviceCategoryName);
		serviceCategory.setVendor(vendor);
		serviceCategoryService.save(serviceCategory);
		
		return "redirect:/viewServiceCategorys";

	}
	
	@GetMapping("/getVendorPendingServices")
	public String getPendingServices(HttpServletRequest request,Model model,HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		String status="pending";
		List<ServicePayment> servicePayments=servicePaymentService.findAllByServiceIdAndVendorId(status, vendorId);
		
		
		model.addAttribute("servicePayments", servicePayments);
		//model.addAttribute("customers",customers);
		
		request.setAttribute("mode", "MODE_PENDINGSERVICES");
		return "vendorDetails";
	}
	
	@GetMapping("/closePendingService")
	public String closePendingService(@RequestParam("servicePaymentId") int servicePaymentId,Model model,HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		ServicePayment servicePayment=servicePaymentService.findByServicePaymentId(servicePaymentId);
		servicePayment.setStatus("closed");
		servicePaymentService.save(servicePayment);
		
		return "redirect:/getVendorPendingServices";
	}
	
	@GetMapping("/getVendorClosedServices")
	public String getVendorClosedServices(HttpServletRequest request,Model model,HttpSession session) {
		String vendorUserId = (String) session.getAttribute("username");
		Vendor vendor = vendorService.findByVendorUserId(vendorUserId);
		int vendorId=vendor.getId();
		String status="closed";
		List<ServicePayment> servicePayments=servicePaymentService.findAllByServiceIdAndVendorId(status, vendorId);
		
		
		model.addAttribute("servicePayments", servicePayments);
		//model.addAttribute("customers",customers);
		
		request.setAttribute("mode", "MODE_CLOSEDSERVICES");
		return "vendorDetails";
	}
	
	
	
	
	
    //display the secret questions
	@ModelAttribute("secretQ")
	public List<String> populateQ() {
		List<String> secretQ = new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;

	}

}
