package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
@Repository
public interface ProductCategoryDao extends JpaRepository<ProductCategory, Integer> {

	ProductCategory findAllByProductCategoryId(int id);
	
	
	@Query(value = "select * from product_category",nativeQuery = true)
	List<ProductCategory> findCategories();
	
	
	ProductCategory findProductCategoryByProductCategoryName(String name);
		
	//@Query(value = "select product_category_id from product_category where product_category_name=?1",nativeQuery = true)
	ProductCategory findByProductCategoryName(String string);
	
	@Query(value = "select * from product_category group by product_category_name",nativeQuery = true)
	List<ProductCategory> findAllCategories();


	List<ProductCategory> findAllByProductCategoryName(String categoryName);


	

}

