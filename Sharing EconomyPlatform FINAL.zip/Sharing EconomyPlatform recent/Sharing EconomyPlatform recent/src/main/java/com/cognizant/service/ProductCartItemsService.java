package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ProductCartItemsDao;
import com.cognizant.model.ProductCartItems;

@Service
public class ProductCartItemsService {
@Autowired
private ProductCartItemsDao productCartItemsDao;
	public void save(ProductCartItems productCartItems2) {
		productCartItemsDao.save(productCartItems2);
		
	}
	public List<ProductCartItems> findAllByCustomerId(int customerId) {
		return productCartItemsDao.findAllByCustomerId(customerId);
	}
	public ProductCartItems findByCartItemIdAndCustomerId(int cartItemId, int customerId) {
		return productCartItemsDao.findByCartItemIdAndCustomerId(cartItemId,customerId);
	}
	public void delete(ProductCartItems productCartItems) {
		productCartItemsDao.delete(productCartItems);
		
	}

}
