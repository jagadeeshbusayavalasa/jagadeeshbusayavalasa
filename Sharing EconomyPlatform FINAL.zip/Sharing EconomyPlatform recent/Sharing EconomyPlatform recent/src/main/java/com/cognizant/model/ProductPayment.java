package com.cognizant.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class ProductPayment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productPaymentId;
	
	private String number;
	
	private String status;
	
	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	
	public ProductPayment() {
		// TODO Auto-generated constructor stub
	}
	public int getProductPaymentId() {
		return productPaymentId;
	}
	public void setProductPaymentId(int productPaymentId) {
		this.productPaymentId = productPaymentId;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	

}
