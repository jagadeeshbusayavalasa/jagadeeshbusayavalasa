package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.dao.ServiceDao;
import com.cognizant.model.ServiceObject;

@Service
public class ServiceService {
    
	private ServiceDao serviceDao;
     @Autowired
	public ServiceService(ServiceDao serviceDao) {
		super();
		this.serviceDao = serviceDao;
	}

	public void save(ServiceObject service) {
		serviceDao.save(service);
		
	}

	public ServiceObject findByServiceId(int serviceId) {
		return serviceDao.findByServiceId(serviceId);
	}

	public void delete(ServiceObject service) {
		serviceDao.delete(service);
	}


}
