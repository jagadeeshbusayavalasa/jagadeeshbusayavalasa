package com.cognizant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Customer;
import com.cognizant.model.ServiceObject;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {

	Customer findByCustomerUserIdAndPassword(String username, String password);
	
	Customer findByCustomerUserId(String userId);

	Customer findByCustomerUserIdAndSecretQAndSecretAns(String customerUserId, String secretQ, String secretAns);


	

}
