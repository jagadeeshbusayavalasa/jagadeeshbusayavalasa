package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ServiceObject;
import com.cognizant.model.ServiceCategory;
@Repository
public interface ServiceCategoryDao extends JpaRepository<ServiceCategory, Integer> {
	@Query(value = "select * from service_category",nativeQuery = true)
	List<ServiceCategory> findCategories();

	
	ServiceCategory findServiceCategoryByServiceCategoryName(String categotyName);

	
	ServiceCategory findByServiceCategoryName(String categoryName);

	
	@Query(value = "select * from service_category group by service_category_name",nativeQuery = true)
	List<ServiceCategory> findAllCategories();

	
	ServiceCategory findByServiceCategoryId(int serviceCategoryId);

	
	ServiceCategory findByServiceCategoryIdAndVendorId(int serviceCategoryId, int vendorId);


	List<ServiceCategory> findAllByServiceCategoryName(String categoryName);


	
}
