package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.model.ServiceCategory;
@Service
public class ServiceCategoryService{
	@Autowired
	private ServiceCategoryDao serviceCategoryDao;
	
	
	public List<String> getServiceCategories() {
		List<String> categoryName=new ArrayList<>();
		List<ServiceCategory> categories=serviceCategoryDao.findCategories();
		for(ServiceCategory category:categories) {
			categoryName.add(category.getServiceCategoryName());
		}
		
		return categoryName;
	}



	public List<String> getAllServiceCategories() {
		List<String> categoryName=new ArrayList<>();
		List<ServiceCategory> allCategories=serviceCategoryDao.findAllCategories();
		for(ServiceCategory category:allCategories) {
			categoryName.add(category.getServiceCategoryName());
		}
		
		return categoryName;
	}


	public void save(ServiceCategory serviceCategory) {
		serviceCategoryDao.save(serviceCategory);
	}


	public List<ServiceCategory> findAll() {
		
		return serviceCategoryDao.findAll();
	}



	public ServiceCategory findServiceCategoryByServiceCategoryName(String categoryName) {
		return serviceCategoryDao.findServiceCategoryByServiceCategoryName(categoryName);
	}



	public ServiceCategory findByServiceCategoryName(String categoryName) {
		return serviceCategoryDao.findByServiceCategoryName(categoryName);
	}



	public ServiceCategory findByServiceCategoryId(int serviceCategoryId) {
		return serviceCategoryDao.findByServiceCategoryId(serviceCategoryId);
	}



	public List<ServiceCategory> findAllByServiceCategoryName(String categoryName) {
		return serviceCategoryDao.findAllByServiceCategoryName(categoryName);
	}


	
	
}
